﻿namespace Compra_y_Venta_Veh
{
    partial class Carro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdbChevrolet = new System.Windows.Forms.RadioButton();
            this.rdbKia = new System.Windows.Forms.RadioButton();
            this.rdbNissan = new System.Windows.Forms.RadioButton();
            this.rdbToyota = new System.Windows.Forms.RadioButton();
            this.grpChevrolet = new System.Windows.Forms.GroupBox();
            this.rdbChevrCamaro = new System.Windows.Forms.RadioButton();
            this.rdbChevAveo = new System.Windows.Forms.RadioButton();
            this.rdbChevSpark = new System.Windows.Forms.RadioButton();
            this.grpKia = new System.Windows.Forms.GroupBox();
            this.rdbKiaSportage = new System.Windows.Forms.RadioButton();
            this.rdbKiaCeed = new System.Windows.Forms.RadioButton();
            this.rdbKiaStinger = new System.Windows.Forms.RadioButton();
            this.grpNissan = new System.Windows.Forms.GroupBox();
            this.rdbNissanLeaf = new System.Windows.Forms.RadioButton();
            this.rdbNissanPuls = new System.Windows.Forms.RadioButton();
            this.rdbNissanGT = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.grpToyota = new System.Windows.Forms.GroupBox();
            this.rdbToyoGT = new System.Windows.Forms.RadioButton();
            this.rdbToyoYar = new System.Windows.Forms.RadioButton();
            this.rdbToyoAYG = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.rdbColor1 = new System.Windows.Forms.RadioButton();
            this.grpColorChev = new System.Windows.Forms.GroupBox();
            this.rdbColor2 = new System.Windows.Forms.RadioButton();
            this.grpColorKia = new System.Windows.Forms.GroupBox();
            this.rdbColor3 = new System.Windows.Forms.RadioButton();
            this.grpColorNissan = new System.Windows.Forms.GroupBox();
            this.rdbColor4 = new System.Windows.Forms.RadioButton();
            this.grpColorToyo = new System.Windows.Forms.GroupBox();
            this.grpChevrolet.SuspendLayout();
            this.grpKia.SuspendLayout();
            this.grpNissan.SuspendLayout();
            this.grpToyota.SuspendLayout();
            this.grpColorChev.SuspendLayout();
            this.grpColorKia.SuspendLayout();
            this.grpColorNissan.SuspendLayout();
            this.grpColorToyo.SuspendLayout();
            this.SuspendLayout();
            // 
            // rdbChevrolet
            // 
            this.rdbChevrolet.AutoSize = true;
            this.rdbChevrolet.BackColor = System.Drawing.Color.Transparent;
            this.rdbChevrolet.Location = new System.Drawing.Point(69, 49);
            this.rdbChevrolet.Name = "rdbChevrolet";
            this.rdbChevrolet.Size = new System.Drawing.Size(101, 24);
            this.rdbChevrolet.TabIndex = 0;
            this.rdbChevrolet.TabStop = true;
            this.rdbChevrolet.Text = "Chevrolet";
            this.rdbChevrolet.UseVisualStyleBackColor = false;
            this.rdbChevrolet.CheckedChanged += new System.EventHandler(this.rdbChevrolet_CheckedChanged);
            // 
            // rdbKia
            // 
            this.rdbKia.AutoSize = true;
            this.rdbKia.BackColor = System.Drawing.Color.Transparent;
            this.rdbKia.Location = new System.Drawing.Point(320, 49);
            this.rdbKia.Name = "rdbKia";
            this.rdbKia.Size = new System.Drawing.Size(49, 24);
            this.rdbKia.TabIndex = 1;
            this.rdbKia.TabStop = true;
            this.rdbKia.Text = "Kia";
            this.rdbKia.UseVisualStyleBackColor = false;
            this.rdbKia.CheckedChanged += new System.EventHandler(this.rdbKia_CheckedChanged);
            // 
            // rdbNissan
            // 
            this.rdbNissan.AutoSize = true;
            this.rdbNissan.BackColor = System.Drawing.Color.Transparent;
            this.rdbNissan.Location = new System.Drawing.Point(524, 49);
            this.rdbNissan.Name = "rdbNissan";
            this.rdbNissan.Size = new System.Drawing.Size(72, 24);
            this.rdbNissan.TabIndex = 2;
            this.rdbNissan.TabStop = true;
            this.rdbNissan.Text = "Nissan";
            this.rdbNissan.UseVisualStyleBackColor = false;
            this.rdbNissan.CheckedChanged += new System.EventHandler(this.rdbNissan_CheckedChanged);
            // 
            // rdbToyota
            // 
            this.rdbToyota.AutoSize = true;
            this.rdbToyota.BackColor = System.Drawing.Color.Transparent;
            this.rdbToyota.Location = new System.Drawing.Point(749, 49);
            this.rdbToyota.Name = "rdbToyota";
            this.rdbToyota.Size = new System.Drawing.Size(75, 24);
            this.rdbToyota.TabIndex = 5;
            this.rdbToyota.TabStop = true;
            this.rdbToyota.Text = "Toyota";
            this.rdbToyota.UseVisualStyleBackColor = false;
            this.rdbToyota.CheckedChanged += new System.EventHandler(this.rdbToyota_CheckedChanged);
            // 
            // grpChevrolet
            // 
            this.grpChevrolet.BackColor = System.Drawing.Color.Transparent;
            this.grpChevrolet.Controls.Add(this.rdbChevrCamaro);
            this.grpChevrolet.Controls.Add(this.rdbChevAveo);
            this.grpChevrolet.Controls.Add(this.rdbChevSpark);
            this.grpChevrolet.Enabled = false;
            this.grpChevrolet.Location = new System.Drawing.Point(41, 124);
            this.grpChevrolet.Name = "grpChevrolet";
            this.grpChevrolet.Size = new System.Drawing.Size(157, 130);
            this.grpChevrolet.TabIndex = 6;
            this.grpChevrolet.TabStop = false;
            this.grpChevrolet.Text = "Chevrolet";
            // 
            // rdbChevrCamaro
            // 
            this.rdbChevrCamaro.AutoSize = true;
            this.rdbChevrCamaro.Location = new System.Drawing.Point(7, 99);
            this.rdbChevrCamaro.Name = "rdbChevrCamaro";
            this.rdbChevrCamaro.Size = new System.Drawing.Size(87, 24);
            this.rdbChevrCamaro.TabIndex = 2;
            this.rdbChevrCamaro.TabStop = true;
            this.rdbChevrCamaro.Text = "Camaro";
            this.rdbChevrCamaro.UseVisualStyleBackColor = true;
            // 
            // rdbChevAveo
            // 
            this.rdbChevAveo.AutoSize = true;
            this.rdbChevAveo.Location = new System.Drawing.Point(7, 68);
            this.rdbChevAveo.Name = "rdbChevAveo";
            this.rdbChevAveo.Size = new System.Drawing.Size(68, 24);
            this.rdbChevAveo.TabIndex = 1;
            this.rdbChevAveo.TabStop = true;
            this.rdbChevAveo.Text = "Aveo";
            this.rdbChevAveo.UseVisualStyleBackColor = true;
            // 
            // rdbChevSpark
            // 
            this.rdbChevSpark.AutoSize = true;
            this.rdbChevSpark.Location = new System.Drawing.Point(7, 37);
            this.rdbChevSpark.Name = "rdbChevSpark";
            this.rdbChevSpark.Size = new System.Drawing.Size(67, 24);
            this.rdbChevSpark.TabIndex = 0;
            this.rdbChevSpark.TabStop = true;
            this.rdbChevSpark.Text = "Spark";
            this.rdbChevSpark.UseVisualStyleBackColor = true;
            // 
            // grpKia
            // 
            this.grpKia.BackColor = System.Drawing.Color.Transparent;
            this.grpKia.Controls.Add(this.rdbKiaSportage);
            this.grpKia.Controls.Add(this.rdbKiaCeed);
            this.grpKia.Controls.Add(this.rdbKiaStinger);
            this.grpKia.Enabled = false;
            this.grpKia.Location = new System.Drawing.Point(269, 124);
            this.grpKia.Name = "grpKia";
            this.grpKia.Size = new System.Drawing.Size(157, 130);
            this.grpKia.TabIndex = 7;
            this.grpKia.TabStop = false;
            this.grpKia.Text = "Kia";
            // 
            // rdbKiaSportage
            // 
            this.rdbKiaSportage.AutoSize = true;
            this.rdbKiaSportage.Location = new System.Drawing.Point(6, 99);
            this.rdbKiaSportage.Name = "rdbKiaSportage";
            this.rdbKiaSportage.Size = new System.Drawing.Size(94, 24);
            this.rdbKiaSportage.TabIndex = 5;
            this.rdbKiaSportage.TabStop = true;
            this.rdbKiaSportage.Text = "Sportage";
            this.rdbKiaSportage.UseVisualStyleBackColor = true;
            // 
            // rdbKiaCeed
            // 
            this.rdbKiaCeed.AutoSize = true;
            this.rdbKiaCeed.Location = new System.Drawing.Point(6, 68);
            this.rdbKiaCeed.Name = "rdbKiaCeed";
            this.rdbKiaCeed.Size = new System.Drawing.Size(69, 24);
            this.rdbKiaCeed.TabIndex = 4;
            this.rdbKiaCeed.TabStop = true;
            this.rdbKiaCeed.Text = "Ceed";
            this.rdbKiaCeed.UseVisualStyleBackColor = true;
            // 
            // rdbKiaStinger
            // 
            this.rdbKiaStinger.AutoSize = true;
            this.rdbKiaStinger.Location = new System.Drawing.Point(6, 37);
            this.rdbKiaStinger.Name = "rdbKiaStinger";
            this.rdbKiaStinger.Size = new System.Drawing.Size(76, 24);
            this.rdbKiaStinger.TabIndex = 3;
            this.rdbKiaStinger.TabStop = true;
            this.rdbKiaStinger.Text = "Stinger";
            this.rdbKiaStinger.UseVisualStyleBackColor = true;
            // 
            // grpNissan
            // 
            this.grpNissan.BackColor = System.Drawing.Color.Transparent;
            this.grpNissan.Controls.Add(this.rdbNissanLeaf);
            this.grpNissan.Controls.Add(this.rdbNissanPuls);
            this.grpNissan.Controls.Add(this.rdbNissanGT);
            this.grpNissan.Enabled = false;
            this.grpNissan.Location = new System.Drawing.Point(493, 124);
            this.grpNissan.Name = "grpNissan";
            this.grpNissan.Size = new System.Drawing.Size(157, 130);
            this.grpNissan.TabIndex = 8;
            this.grpNissan.TabStop = false;
            this.grpNissan.Text = "Nissan";
            // 
            // rdbNissanLeaf
            // 
            this.rdbNissanLeaf.AutoSize = true;
            this.rdbNissanLeaf.Location = new System.Drawing.Point(6, 99);
            this.rdbNissanLeaf.Name = "rdbNissanLeaf";
            this.rdbNissanLeaf.Size = new System.Drawing.Size(59, 24);
            this.rdbNissanLeaf.TabIndex = 19;
            this.rdbNissanLeaf.TabStop = true;
            this.rdbNissanLeaf.Text = "Leaf";
            this.rdbNissanLeaf.UseVisualStyleBackColor = true;
            // 
            // rdbNissanPuls
            // 
            this.rdbNissanPuls.AutoSize = true;
            this.rdbNissanPuls.Location = new System.Drawing.Point(6, 37);
            this.rdbNissanPuls.Name = "rdbNissanPuls";
            this.rdbNissanPuls.Size = new System.Drawing.Size(69, 24);
            this.rdbNissanPuls.TabIndex = 17;
            this.rdbNissanPuls.TabStop = true;
            this.rdbNissanPuls.Text = "Pulsar";
            this.rdbNissanPuls.UseVisualStyleBackColor = true;
            // 
            // rdbNissanGT
            // 
            this.rdbNissanGT.AutoSize = true;
            this.rdbNissanGT.Location = new System.Drawing.Point(6, 68);
            this.rdbNissanGT.Name = "rdbNissanGT";
            this.rdbNissanGT.Size = new System.Drawing.Size(59, 24);
            this.rdbNissanGT.TabIndex = 18;
            this.rdbNissanGT.TabStop = true;
            this.rdbNissanGT.Text = "GT-R";
            this.rdbNissanGT.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(25, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 19);
            this.label1.TabIndex = 9;
            this.label1.Text = "Marca";
            // 
            // grpToyota
            // 
            this.grpToyota.BackColor = System.Drawing.Color.Transparent;
            this.grpToyota.Controls.Add(this.rdbToyoGT);
            this.grpToyota.Controls.Add(this.rdbToyoYar);
            this.grpToyota.Controls.Add(this.rdbToyoAYG);
            this.grpToyota.Enabled = false;
            this.grpToyota.Location = new System.Drawing.Point(720, 124);
            this.grpToyota.Name = "grpToyota";
            this.grpToyota.Size = new System.Drawing.Size(157, 130);
            this.grpToyota.TabIndex = 9;
            this.grpToyota.TabStop = false;
            this.grpToyota.Text = "Toyota";
            // 
            // rdbToyoGT
            // 
            this.rdbToyoGT.AutoSize = true;
            this.rdbToyoGT.Location = new System.Drawing.Point(6, 99);
            this.rdbToyoGT.Name = "rdbToyoGT";
            this.rdbToyoGT.Size = new System.Drawing.Size(61, 24);
            this.rdbToyoGT.TabIndex = 19;
            this.rdbToyoGT.TabStop = true;
            this.rdbToyoGT.Text = "GT86";
            this.rdbToyoGT.UseVisualStyleBackColor = true;
            // 
            // rdbToyoYar
            // 
            this.rdbToyoYar.AutoSize = true;
            this.rdbToyoYar.Location = new System.Drawing.Point(6, 37);
            this.rdbToyoYar.Name = "rdbToyoYar";
            this.rdbToyoYar.Size = new System.Drawing.Size(66, 24);
            this.rdbToyoYar.TabIndex = 17;
            this.rdbToyoYar.TabStop = true;
            this.rdbToyoYar.Text = "YARIS";
            this.rdbToyoYar.UseVisualStyleBackColor = true;
            // 
            // rdbToyoAYG
            // 
            this.rdbToyoAYG.AutoSize = true;
            this.rdbToyoAYG.Location = new System.Drawing.Point(6, 68);
            this.rdbToyoAYG.Name = "rdbToyoAYG";
            this.rdbToyoAYG.Size = new System.Drawing.Size(71, 24);
            this.rdbToyoAYG.TabIndex = 18;
            this.rdbToyoAYG.TabStop = true;
            this.rdbToyoAYG.Text = "AYGO";
            this.rdbToyoAYG.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(25, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 18);
            this.label2.TabIndex = 10;
            this.label2.Text = "Modelo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(25, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 18);
            this.label3.TabIndex = 11;
            this.label3.Text = "Color";
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(360, 453);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(178, 47);
            this.btnAceptar.TabIndex = 16;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // rdbColor1
            // 
            this.rdbColor1.AutoSize = true;
            this.rdbColor1.Location = new System.Drawing.Point(7, 16);
            this.rdbColor1.Name = "rdbColor1";
            this.rdbColor1.Size = new System.Drawing.Size(73, 24);
            this.rdbColor1.TabIndex = 0;
            this.rdbColor1.TabStop = true;
            this.rdbColor1.Text = "Negro";
            this.rdbColor1.UseVisualStyleBackColor = true;
            // 
            // grpColorChev
            // 
            this.grpColorChev.BackColor = System.Drawing.Color.Black;
            this.grpColorChev.Controls.Add(this.rdbColor1);
            this.grpColorChev.Enabled = false;
            this.grpColorChev.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.grpColorChev.Location = new System.Drawing.Point(41, 296);
            this.grpColorChev.Name = "grpColorChev";
            this.grpColorChev.Size = new System.Drawing.Size(157, 130);
            this.grpColorChev.TabIndex = 12;
            this.grpColorChev.TabStop = false;
            // 
            // rdbColor2
            // 
            this.rdbColor2.AutoSize = true;
            this.rdbColor2.Location = new System.Drawing.Point(6, 16);
            this.rdbColor2.Name = "rdbColor2";
            this.rdbColor2.Size = new System.Drawing.Size(59, 24);
            this.rdbColor2.TabIndex = 1;
            this.rdbColor2.TabStop = true;
            this.rdbColor2.Text = "Rojo";
            this.rdbColor2.UseVisualStyleBackColor = true;
            // 
            // grpColorKia
            // 
            this.grpColorKia.BackColor = System.Drawing.Color.Brown;
            this.grpColorKia.Controls.Add(this.rdbColor2);
            this.grpColorKia.Enabled = false;
            this.grpColorKia.Location = new System.Drawing.Point(269, 296);
            this.grpColorKia.Name = "grpColorKia";
            this.grpColorKia.Size = new System.Drawing.Size(157, 130);
            this.grpColorKia.TabIndex = 13;
            this.grpColorKia.TabStop = false;
            // 
            // rdbColor3
            // 
            this.rdbColor3.AutoSize = true;
            this.rdbColor3.Location = new System.Drawing.Point(6, 16);
            this.rdbColor3.Name = "rdbColor3";
            this.rdbColor3.Size = new System.Drawing.Size(56, 24);
            this.rdbColor3.TabIndex = 1;
            this.rdbColor3.TabStop = true;
            this.rdbColor3.Text = "Azul";
            this.rdbColor3.UseVisualStyleBackColor = true;
            // 
            // grpColorNissan
            // 
            this.grpColorNissan.BackColor = System.Drawing.Color.DarkBlue;
            this.grpColorNissan.Controls.Add(this.rdbColor3);
            this.grpColorNissan.Enabled = false;
            this.grpColorNissan.Location = new System.Drawing.Point(493, 296);
            this.grpColorNissan.Name = "grpColorNissan";
            this.grpColorNissan.Size = new System.Drawing.Size(157, 130);
            this.grpColorNissan.TabIndex = 14;
            this.grpColorNissan.TabStop = false;
            // 
            // rdbColor4
            // 
            this.rdbColor4.AutoSize = true;
            this.rdbColor4.Location = new System.Drawing.Point(6, 16);
            this.rdbColor4.Name = "rdbColor4";
            this.rdbColor4.Size = new System.Drawing.Size(72, 24);
            this.rdbColor4.TabIndex = 1;
            this.rdbColor4.TabStop = true;
            this.rdbColor4.Text = "Plomo";
            this.rdbColor4.UseVisualStyleBackColor = true;
            // 
            // grpColorToyo
            // 
            this.grpColorToyo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.grpColorToyo.Controls.Add(this.rdbColor4);
            this.grpColorToyo.Enabled = false;
            this.grpColorToyo.Location = new System.Drawing.Point(720, 296);
            this.grpColorToyo.Name = "grpColorToyo";
            this.grpColorToyo.Size = new System.Drawing.Size(157, 130);
            this.grpColorToyo.TabIndex = 15;
            this.grpColorToyo.TabStop = false;
            // 
            // Carro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Compra_y_Venta_Veh.Properties.Resources._325420;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(911, 525);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.grpColorToyo);
            this.Controls.Add(this.grpColorNissan);
            this.Controls.Add(this.grpColorKia);
            this.Controls.Add(this.grpColorChev);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.grpToyota);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpNissan);
            this.Controls.Add(this.grpKia);
            this.Controls.Add(this.grpChevrolet);
            this.Controls.Add(this.rdbToyota);
            this.Controls.Add(this.rdbNissan);
            this.Controls.Add(this.rdbKia);
            this.Controls.Add(this.rdbChevrolet);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Carro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comprar";
            this.grpChevrolet.ResumeLayout(false);
            this.grpChevrolet.PerformLayout();
            this.grpKia.ResumeLayout(false);
            this.grpKia.PerformLayout();
            this.grpNissan.ResumeLayout(false);
            this.grpNissan.PerformLayout();
            this.grpToyota.ResumeLayout(false);
            this.grpToyota.PerformLayout();
            this.grpColorChev.ResumeLayout(false);
            this.grpColorChev.PerformLayout();
            this.grpColorKia.ResumeLayout(false);
            this.grpColorKia.PerformLayout();
            this.grpColorNissan.ResumeLayout(false);
            this.grpColorNissan.PerformLayout();
            this.grpColorToyo.ResumeLayout(false);
            this.grpColorToyo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAceptar;
        public System.Windows.Forms.RadioButton rdbChevrolet;
        public System.Windows.Forms.RadioButton rdbKia;
        public System.Windows.Forms.RadioButton rdbNissan;
        public System.Windows.Forms.RadioButton rdbToyota;
        public System.Windows.Forms.GroupBox grpChevrolet;
        public System.Windows.Forms.GroupBox grpKia;
        public System.Windows.Forms.GroupBox grpNissan;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.GroupBox grpToyota;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.RadioButton rdbChevrCamaro;
        public System.Windows.Forms.RadioButton rdbChevAveo;
        public System.Windows.Forms.RadioButton rdbChevSpark;
        public System.Windows.Forms.RadioButton rdbKiaSportage;
        public System.Windows.Forms.RadioButton rdbKiaCeed;
        public System.Windows.Forms.RadioButton rdbKiaStinger;
        public System.Windows.Forms.RadioButton rdbNissanLeaf;
        public System.Windows.Forms.RadioButton rdbNissanPuls;
        public System.Windows.Forms.RadioButton rdbNissanGT;
        public System.Windows.Forms.RadioButton rdbToyoGT;
        public System.Windows.Forms.RadioButton rdbToyoYar;
        public System.Windows.Forms.RadioButton rdbToyoAYG;
        public System.Windows.Forms.RadioButton rdbColor1;
        public System.Windows.Forms.GroupBox grpColorChev;
        public System.Windows.Forms.RadioButton rdbColor2;
        public System.Windows.Forms.GroupBox grpColorKia;
        public System.Windows.Forms.RadioButton rdbColor3;
        public System.Windows.Forms.GroupBox grpColorNissan;
        public System.Windows.Forms.RadioButton rdbColor4;
        public System.Windows.Forms.GroupBox grpColorToyo;

    }
}