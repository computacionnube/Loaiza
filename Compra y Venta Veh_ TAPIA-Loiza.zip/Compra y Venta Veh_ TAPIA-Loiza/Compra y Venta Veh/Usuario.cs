﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_y_Venta_Veh
{
    public partial class Usuario : Form
    {
        public Usuario()
        {
            InitializeComponent();
        }

        private void carroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Carro car= new Carro();
            car.Show();
        }

        private void comprarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Carro car = new Carro();
            car.Show();
        }
    }
}
