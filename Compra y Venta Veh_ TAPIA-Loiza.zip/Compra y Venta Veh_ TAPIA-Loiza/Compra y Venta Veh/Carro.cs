﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_y_Venta_Veh
{
    public partial class Carro : Form
    {
        public Carro()
        {
            InitializeComponent();
        }

        int i = 1;
        
        private void rdbChevrolet_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbChevrolet.Checked==true)
            {
                grpChevrolet.Enabled = true;
                grpColorToyo.Enabled = true;
                grpColorNissan.Enabled = true;
                grpColorKia.Enabled = true;
                grpColorChev.Enabled = true;
            }
            else
            {
                grpChevrolet.Enabled = false;
                grpColorToyo.Enabled = false;
                grpColorNissan.Enabled = false;
                grpColorKia.Enabled = false;
                grpColorChev.Enabled = false;
            }
        }

        private void rdbKia_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbKia.Checked==true)
            {
                grpKia.Enabled = true;
                grpColorToyo.Enabled = true;
                grpColorNissan.Enabled = true;
                grpColorKia.Enabled = true;
                grpColorChev.Enabled = true;
            }
            else
            {
                grpKia.Enabled = false;
                grpColorToyo.Enabled = false;
                grpColorNissan.Enabled = false;
                grpColorKia.Enabled = false;
                grpColorChev.Enabled = false;
            }
        }

        private void rdbNissan_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbNissan.Checked==true)
            {
                grpNissan.Enabled = true;
                grpColorToyo.Enabled = true;
                grpColorNissan.Enabled = true;
                grpColorKia.Enabled = true;
                grpColorChev.Enabled = true;
            }
            else
            {
                grpNissan.Enabled = false;
                grpColorToyo.Enabled = false;
                grpColorNissan.Enabled = false;
                grpColorKia.Enabled = false;
                grpColorChev.Enabled = false;
            }
        }
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            frmComprar Compra = new frmComprar();
            string Chevrolet, Kia, Nissan, Toyota,Camaro,Aveo,Spark, Stinger, Ceed, Sportage, Pulsar, GT_R, Leaf, YARIS, AYGO, GT86, Negro, Rojo, Azul, Plomo;
            Chevrolet = rdbChevrolet.Text;
            Kia = rdbKia.Text;
            Nissan = rdbNissan.Text;
            Toyota = rdbToyota.Text;
            Aveo = rdbChevAveo.Text;
            Camaro = rdbChevrCamaro.Text;
            Spark = rdbChevSpark.Text;
            Stinger = rdbKiaStinger.Text;
            Ceed = rdbKiaCeed.Text;
            Sportage = rdbKiaSportage.Text;
            Pulsar = rdbNissanPuls.Text;
            GT_R = rdbNissanGT.Text;
            Leaf = rdbNissanLeaf.Text;
            YARIS = rdbToyoYar.Text;
            AYGO = rdbToyoAYG.Text;
            GT86 = rdbToyoGT.Text;
            Negro = rdbColor1.Text;
            Rojo = rdbColor2.Text;
            Azul = rdbColor3.Text;
            Plomo = rdbColor4.Text;
            //Validacion para data grid view en color Negro Chevrolet
            if (rdbChevrolet.Checked==true && rdbChevAveo.Checked==true && rdbColor1.Checked==true)
            {
                Compra.dgvCompra.Rows.Add(i, Chevrolet,Aveo, Negro);
            }
            else
            {
                if (rdbChevrolet.Checked==true && rdbChevrCamaro.Checked==true && rdbColor1.Checked==true)
                {
                    Compra.dgvCompra.Rows.Add(i,Chevrolet,Camaro,Negro);
                }
                else
                {
                    if (rdbChevrolet.Checked==true && rdbChevSpark.Checked==true && rdbColor1.Checked==true)
                    {
                        Compra.dgvCompra.Rows.Add(i,Chevrolet,Spark,Negro);
                    }
                }
            }
            //Validacion para data grid view en color Rojo Chevrolet
            if (rdbChevrolet.Checked == true && rdbChevAveo.Checked == true && rdbColor2.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Chevrolet, Aveo, Rojo);
            }
            else
            {
                if (rdbChevrolet.Checked == true && rdbChevrCamaro.Checked == true && rdbColor2.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Chevrolet, Camaro, Rojo);
                }
                else
                {
                    if (rdbChevrolet.Checked == true && rdbChevSpark.Checked == true && rdbColor2.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Chevrolet, Spark, Rojo);
                    }
                }
            }
            //Validacion para data grid view en color Azul Chevrolet
            if (rdbChevrolet.Checked == true && rdbChevAveo.Checked == true && rdbColor3.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Chevrolet, Aveo, Azul);
            }
            else
            {
                if (rdbChevrolet.Checked == true && rdbChevrCamaro.Checked == true && rdbColor3.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Chevrolet, Camaro, Azul);
                }
                else
                {
                    if (rdbChevrolet.Checked == true && rdbChevSpark.Checked == true && rdbColor3.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Chevrolet, Spark, Azul);
                    }
                }
            }
            //Validación para data grid view en color Plomo Chevrolet
            if (rdbChevrolet.Checked == true && rdbChevAveo.Checked == true && rdbColor4.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Chevrolet, Aveo, Plomo);
            }
            else
            {
                if (rdbChevrolet.Checked == true && rdbChevrCamaro.Checked == true && rdbColor4.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Chevrolet, Camaro, Plomo);
                }
                else
                {
                    if (rdbChevrolet.Checked == true && rdbChevSpark.Checked == true && rdbColor4.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Chevrolet, Spark, Plomo);
                    }
                }
            }
            //Validación para data grid view en color Negro Kia
            if (rdbKia.Checked == true && rdbKiaCeed.Checked == true && rdbColor1.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Kia, Ceed, Negro);
            }
            else
            {
                if (rdbKia.Checked == true && rdbKiaStinger.Checked == true && rdbColor1.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Kia, Stinger, Negro);
                }
                else
                {
                    if (rdbKia.Checked == true && rdbKiaSportage.Checked == true && rdbColor1.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Kia, Sportage, Negro);
                    }
                }
            }
            //Validación para data grid view en color Rojo Kia
            if (rdbKia.Checked == true && rdbKiaCeed.Checked == true && rdbColor2.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Kia, Ceed, Rojo);
            }
            else
            {
                if (rdbKia.Checked == true && rdbKiaStinger.Checked == true && rdbColor2.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Kia, Stinger, Rojo);
                }
                else
                {
                    if (rdbKia.Checked == true && rdbKiaSportage.Checked == true && rdbColor2.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Kia, Sportage, Rojo);
                    }
                }
            }
            //Validación para data grid view en color Azul Kia
            if (rdbKia.Checked == true && rdbKiaCeed.Checked == true && rdbColor3.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Kia, Ceed, Azul);
            }
            else
            {
                if (rdbKia.Checked == true && rdbKiaStinger.Checked == true && rdbColor3.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Kia, Stinger, Azul);
                }
                else
                {
                    if (rdbKia.Checked == true && rdbKiaSportage.Checked == true && rdbColor3.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Kia, Sportage, Azul);
                    }
                }
            }
            //Validación para data grid view en color Plomo Kia
            if (rdbKia.Checked == true && rdbKiaCeed.Checked == true && rdbColor4.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Kia, Ceed, Plomo);
            }
            else
            {
                if (rdbKia.Checked == true && rdbKiaStinger.Checked == true && rdbColor4.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Kia, Stinger, Plomo);
                }
                else
                {
                    if (rdbKia.Checked == true && rdbKiaSportage.Checked == true && rdbColor4.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Kia, Sportage, Plomo);
                    }
                }
            }
            //Validación para data grid view en color Negro Nissan
            if (rdbNissan.Checked == true && rdbNissanPuls.Checked == true && rdbColor1.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Nissan, Pulsar, Negro);
            }
            else
            {
                if (rdbNissan.Checked == true && rdbNissanGT.Checked == true && rdbColor1.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Nissan, GT_R, Negro);
                }
                else
                {
                    if (rdbNissan.Checked == true && rdbNissanLeaf.Checked == true && rdbColor1.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Nissan, Leaf, Negro);
                    }
                }
            }
            //Validación para data grid view en color Rojo Nissan
            if (rdbNissan.Checked == true && rdbNissanPuls.Checked == true && rdbColor2.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Nissan, Pulsar, Rojo);
            }
            else
            {
                if (rdbNissan.Checked == true && rdbNissanGT.Checked == true && rdbColor2.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Nissan, GT_R, Rojo);
                }
                else
                {
                    if (rdbNissan.Checked == true && rdbNissanLeaf.Checked == true && rdbColor2.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Nissan, Leaf, Rojo);
                    }
                }
            }
            //Validación para data grid view en color Azul Nissan
            if (rdbNissan.Checked == true && rdbNissanPuls.Checked == true && rdbColor3.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Nissan, Pulsar, Azul);
            }
            else
            {
                if (rdbNissan.Checked == true && rdbNissanGT.Checked == true && rdbColor3.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Nissan, GT_R, Azul);
                }
                else
                {
                    if (rdbNissan.Checked == true && rdbNissanLeaf.Checked == true && rdbColor3.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Nissan, Leaf, Azul);
                    }
                }
            }
             //Validación para data grid view en color Plomo Nissan
            if (rdbNissan.Checked == true && rdbNissanPuls.Checked == true && rdbColor4.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Nissan, Pulsar, Plomo);
            }
            else
            {
                if (rdbNissan.Checked == true && rdbNissanGT.Checked == true && rdbColor4.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Nissan, GT_R, Plomo);
                }
                else
                {
                    if (rdbNissan.Checked == true && rdbNissanLeaf.Checked == true && rdbColor4.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Nissan, Leaf, Plomo);
                    }
                }
            }
            //Validacion para data grid view en color Negro Toyota
            if (rdbToyota.Checked == true && rdbToyoYar.Checked == true && rdbColor1.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Toyota, YARIS, Negro);
            }
            else
            {
                if (rdbToyota.Checked == true && rdbToyoAYG.Checked == true && rdbColor1.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Toyota, AYGO, Negro);
                }
                else
                {
                    if (rdbToyota.Checked == true && rdbToyoGT.Checked == true && rdbColor1.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Toyota, GT86, Negro);
                    }
                }
            }
            //Validacion para data grid view en color Rojo Toyota
            if (rdbToyota.Checked == true && rdbToyoYar.Checked == true && rdbColor2.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Toyota, YARIS, Rojo);
            }
            else
            {
                if (rdbToyota.Checked == true && rdbToyoAYG.Checked == true && rdbColor2.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Toyota, AYGO, Rojo);
                }
                else
                {
                    if (rdbToyota.Checked == true && rdbToyoGT.Checked == true && rdbColor2.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Toyota, GT86, Rojo);
                    }
                }
            }
            //Validacion para data grid view en color Azul Toyota
            if (rdbToyota.Checked == true && rdbToyoYar.Checked == true && rdbColor3.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Toyota, YARIS, Azul);
            }
            else
            {
                if (rdbToyota.Checked == true && rdbToyoAYG.Checked == true && rdbColor3.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Toyota, AYGO, Azul);
                }
                else
                {
                    if (rdbToyota.Checked == true && rdbToyoGT.Checked == true && rdbColor3.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Toyota, GT86, Azul);
                    }
                }
            }
            //Validacion para data grid view en color Plomo Toyota
            if (rdbToyota.Checked == true && rdbToyoYar.Checked == true && rdbColor4.Checked == true)
            {
                Compra.dgvCompra.Rows.Add(i, Toyota, YARIS, Plomo);
            }
            else
            {
                if (rdbToyota.Checked == true && rdbToyoAYG.Checked == true && rdbColor4.Checked == true)
                {
                    Compra.dgvCompra.Rows.Add(i, Toyota, AYGO, Plomo);
                }
                else
                {
                    if (rdbToyota.Checked == true && rdbToyoGT.Checked == true && rdbColor4.Checked == true)
                    {
                        Compra.dgvCompra.Rows.Add(i, Toyota, GT86, Plomo);
                    }
                }
            }
            i++;
            Compra.Show();
            this.Hide();
        }

        private void rdbToyota_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbToyota.Checked==true)
            {
                grpToyota.Enabled = true;
                grpColorToyo.Enabled = true;
                grpColorNissan.Enabled = true;
                grpColorKia.Enabled = true;
                grpColorChev.Enabled = true;
            }
            else
            {
                grpToyota.Enabled = true;
                grpColorToyo.Enabled = false;
                grpColorNissan.Enabled = false;
                grpColorKia.Enabled = false;
                grpColorChev.Enabled = false;
            }
        }

        
    }
}
