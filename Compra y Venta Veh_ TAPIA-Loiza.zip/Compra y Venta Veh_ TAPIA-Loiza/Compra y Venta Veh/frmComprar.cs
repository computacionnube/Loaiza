﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_y_Venta_Veh
{
    public partial class frmComprar : Form
    {
        public frmComprar()
        {
            InitializeComponent();
        }
        Carro carr = new Carro();
        int pos;
        double precio = 0;
        private void btnComprar_Click(object sender, EventArgs e)
        {
            //Precio Chrevrolet
            if (carr.rdbChevrolet.Checked == true && carr.rdbChevAveo.Checked == true && carr.rdbColor1.Checked == true)
            {
                precio = 13.000;
                
            }
            else
            {
                if (carr.rdbChevrolet.Checked == true && carr.rdbChevrCamaro.Checked == true )
                {
                    precio = 40.000;
                    MessageBox.Show("Su vehiculo tiene un costo de:40.000 " , "Valor Vehiculo", MessageBoxButtons.OK);
                }
                else
                {
                    if (carr.rdbChevrolet.Checked == true && carr.rdbChevSpark.Checked == true && carr.rdbColor1.Checked == true)
                    {
                        precio = 10.000;
                        MessageBox.Show("Su vehiculo tiene un costo de: " + precio, "Valor Vehiculo", MessageBoxButtons.OK);
                    }
                }
            }
            //precio Kia
            if (carr.rdbKia.Checked == true && carr.rdbKiaCeed.Checked == true && carr.rdbColor1.Checked == true)
            {
                precio = 20.000;
            }
            else
            {
                if (carr.rdbKia.Checked == true && carr.rdbKiaStinger.Checked == true && carr.rdbColor1.Checked == true)
                {
                    precio = 30.000;
                }
                else
                {
                    if (carr.rdbKia.Checked == true && carr.rdbKiaSportage.Checked == true && carr.rdbColor1.Checked == true)
                    {
                        precio = 21.000;
                    }
                }
            }
            //Precio Nissan
            if (carr.rdbNissan.Checked == true && carr.rdbNissanPuls.Checked == true && carr.rdbColor1.Checked == true)
            {
                precio = 25.000;
            }
            else
            {
                if (carr.rdbNissan.Checked == true && carr.rdbNissanGT.Checked == true && carr.rdbColor1.Checked == true)
                {
                    precio = 29.000;
                }
                else
                {
                    if (carr.rdbNissan.Checked == true && carr.rdbNissanLeaf.Checked == true && carr.rdbColor1.Checked == true)
                    {
                        precio = 23.000;
                    }
                }
            }
            //Precio Toyota
            if (carr.rdbToyota.Checked == true && carr.rdbToyoYar.Checked == true && carr.rdbColor2.Checked == true)
            {
                precio = 33.000;
            }
            else
            {
                if (carr.rdbToyota.Checked == true && carr.rdbToyoAYG.Checked == true && carr.rdbColor2.Checked == true)
                {
                    precio = 26.000;
                }
                else
                {
                    if (carr.rdbToyota.Checked == true && carr.rdbToyoGT.Checked == true && carr.rdbColor2.Checked == true)
                    {
                        precio = 17.000;
                    }
                }
            }
            
            
            if (DialogResult.Yes==MessageBox.Show("Nombre: "+txtNombre.Text+" Apellido: "+ txtApellido.Text+ " Cedula: "+txtCedula.Text+ " Dirección: "+txtDireccion.Text+" Num. Cuenta: "+txtCuenta.Text, "Datos Comprador", MessageBoxButtons.OKCancel))
            {
                this.Close();
            }
            
        }

        private void dgvCompra_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos = dgvCompra.CurrentRow.Index;
            //Presentación para data grid view en color Negro Chevrolet
            if (carr.rdbChevrolet.Checked == true && carr.rdbChevAveo.Checked == true && carr.rdbColor1.Checked == true)
            {
                carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbChevAveo.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbChevrolet.Checked == true && carr.rdbChevrCamaro.Checked == true && carr.rdbColor1.Checked == true)
                {
                    carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbChevrCamaro.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbChevrolet.Checked == true && carr.rdbChevSpark.Checked == true && carr.rdbColor1.Checked == true)
                    {
                        carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbChevSpark.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Rojo Chevrolet
            if (carr.rdbChevrolet.Checked == true && carr.rdbChevAveo.Checked == true && carr.rdbColor2.Checked == true)
            {
                carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbChevAveo.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbChevrolet.Checked == true && carr.rdbChevrCamaro.Checked == true && carr.rdbColor2.Checked == true)
                {
                    carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbChevrCamaro.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbChevrolet.Checked == true && carr.rdbChevSpark.Checked == true && carr.rdbColor2.Checked == true)
                    {
                        carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbChevSpark.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Azul Chevrolet
            if (carr.rdbChevrolet.Checked == true && carr.rdbChevAveo.Checked == true && carr.rdbColor3.Checked == true)
            {
                carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbChevAveo.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbChevrolet.Checked == true && carr.rdbChevrCamaro.Checked == true && carr.rdbColor3.Checked == true)
                {
                    carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbChevrCamaro.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbChevrolet.Checked == true && carr.rdbChevSpark.Checked == true && carr.rdbColor3.Checked == true)
                    {
                        carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbChevSpark.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Plomo Chevrolet
            if (carr.rdbChevrolet.Checked == true && carr.rdbChevAveo.Checked == true && carr.rdbColor4.Checked == true)
            {
                carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbChevAveo.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbChevrolet.Checked == true && carr.rdbChevrCamaro.Checked == true && carr.rdbColor4.Checked == true)
                {
                    carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbChevrCamaro.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbChevrolet.Checked == true && carr.rdbChevSpark.Checked == true && carr.rdbColor4.Checked == true)
                    {
                        carr.rdbChevrolet.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbChevSpark.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentaciòn para data grid view en color negro Kia
            if (carr.rdbKia.Checked == true && carr.rdbKiaCeed.Checked == true && carr.rdbColor1.Checked == true)
            {
                carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbKiaCeed.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbKia.Checked == true && carr.rdbKiaStinger.Checked == true && carr.rdbColor1.Checked == true)
                {
                    carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbKiaStinger.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbKia.Checked == true && carr.rdbKiaSportage.Checked == true && carr.rdbColor1.Checked == true)
                    {
                        carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbKiaSportage.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentaciòn para data grid view en color Rojo Kia
            if (carr.rdbKia.Checked == true && carr.rdbKiaCeed.Checked == true && carr.rdbColor2.Checked == true)
            {
                carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbKiaCeed.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbKia.Checked == true && carr.rdbKiaStinger.Checked == true && carr.rdbColor2.Checked == true)
                {
                    carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbKiaStinger.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbKia.Checked == true && carr.rdbKiaSportage.Checked == true && carr.rdbColor2.Checked == true)
                    {
                        carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbKiaSportage.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentaciòn para data grid view en color Azul Kia
            if (carr.rdbKia.Checked == true && carr.rdbKiaCeed.Checked == true && carr.rdbColor3.Checked == true)
            {
                carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbKiaCeed.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbKia.Checked == true && carr.rdbKiaStinger.Checked == true && carr.rdbColor3.Checked == true)
                {
                    carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbKiaStinger.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbKia.Checked == true && carr.rdbKiaSportage.Checked == true && carr.rdbColor3.Checked == true)
                    {
                        carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbKiaSportage.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentaciòn para data grid view en color Plomo Kia
            if (carr.rdbKia.Checked == true && carr.rdbKiaCeed.Checked == true && carr.rdbColor4.Checked == true)
            {
                carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbKiaCeed.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbKia.Checked == true && carr.rdbKiaStinger.Checked == true && carr.rdbColor4.Checked == true)
                {
                    carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbKiaStinger.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbKia.Checked == true && carr.rdbKiaSportage.Checked == true && carr.rdbColor4.Checked == true)
                    {
                        carr.rdbKia.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbKiaSportage.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Negro Nissan
            if (carr.rdbNissan.Checked == true && carr.rdbNissanPuls.Checked == true && carr.rdbColor1.Checked == true)
            {
                carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbNissanPuls.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbNissan.Checked == true && carr.rdbNissanGT.Checked == true && carr.rdbColor1.Checked == true)
                {
                    carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbNissanGT.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbNissan.Checked == true && carr.rdbNissanLeaf.Checked == true && carr.rdbColor1.Checked == true)
                    {
                        carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbNissanLeaf.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Rojo Nissan
            if (carr.rdbNissan.Checked == true && carr.rdbNissanPuls.Checked == true && carr.rdbColor2.Checked == true)
            {
                carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbNissanPuls.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbNissan.Checked == true && carr.rdbNissanGT.Checked == true && carr.rdbColor2.Checked == true)
                {
                    carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbNissanGT.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbNissan.Checked == true && carr.rdbNissanLeaf.Checked == true && carr.rdbColor2.Checked == true)
                    {
                        carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbNissanLeaf.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Azul Nissan
            if (carr.rdbNissan.Checked == true && carr.rdbNissanPuls.Checked == true && carr.rdbColor3.Checked == true)
            {
                carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbNissanPuls.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbNissan.Checked == true && carr.rdbNissanGT.Checked == true && carr.rdbColor3.Checked == true)
                {
                    carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbNissanGT.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbNissan.Checked == true && carr.rdbNissanLeaf.Checked == true && carr.rdbColor3.Checked == true)
                    {
                        carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbNissanLeaf.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Plomo Nissan
            if (carr.rdbNissan.Checked == true && carr.rdbNissanPuls.Checked == true && carr.rdbColor4.Checked == true)
            {
                carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbNissanPuls.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbNissan.Checked == true && carr.rdbNissanGT.Checked == true && carr.rdbColor4.Checked == true)
                {
                    carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbNissanGT.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbNissan.Checked == true && carr.rdbNissanLeaf.Checked == true && carr.rdbColor4.Checked == true)
                    {
                        carr.rdbNissan.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbNissanLeaf.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Negro Toyota
            if (carr.rdbToyota.Checked == true && carr.rdbToyoYar.Checked == true && carr.rdbColor1.Checked == true)
            {
                carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbToyoYar.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbToyota.Checked == true && carr.rdbToyoAYG.Checked == true && carr.rdbColor1.Checked == true)
                {
                    carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbToyoAYG.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbToyota.Checked == true && carr.rdbToyoGT.Checked == true && carr.rdbColor1.Checked == true)
                    {
                        carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbToyoGT.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor1.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Rojo Toyota
            if (carr.rdbToyota.Checked == true && carr.rdbToyoYar.Checked == true && carr.rdbColor2.Checked == true)
            {
                carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbToyoYar.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbToyota.Checked == true && carr.rdbToyoAYG.Checked == true && carr.rdbColor2.Checked == true)
                {
                    carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbToyoAYG.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbToyota.Checked == true && carr.rdbToyoGT.Checked == true && carr.rdbColor2.Checked == true)
                    {
                        carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbToyoGT.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor2.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Azul Toyota
            if (carr.rdbToyota.Checked == true && carr.rdbToyoYar.Checked == true && carr.rdbColor3.Checked == true)
            {
                carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbToyoYar.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbToyota.Checked == true && carr.rdbToyoAYG.Checked == true && carr.rdbColor3.Checked == true)
                {
                    carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbToyoAYG.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbToyota.Checked == true && carr.rdbToyoGT.Checked == true && carr.rdbColor3.Checked == true)
                    {
                        carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbToyoGT.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor3.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            //Presentación para data grid view en color Plomo Toyota
            if (carr.rdbToyota.Checked == true && carr.rdbToyoYar.Checked == true && carr.rdbColor4.Checked == true)
            {
                carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                carr.rdbToyoYar.Text = dgvCompra[2, pos].Value.ToString();
                carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
            }
            else
            {
                if (carr.rdbToyota.Checked == true && carr.rdbToyoAYG.Checked == true && carr.rdbColor4.Checked == true)
                {
                    carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                    carr.rdbToyoAYG.Text = dgvCompra[2, pos].Value.ToString();
                    carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                }
                else
                {
                    if (carr.rdbToyota.Checked == true && carr.rdbToyoGT.Checked == true && carr.rdbColor4.Checked == true)
                    {
                        carr.rdbToyota.Text = dgvCompra[1, pos].Value.ToString();
                        carr.rdbToyoGT.Text = dgvCompra[2, pos].Value.ToString();
                        carr.rdbColor4.Text = dgvCompra[3, pos].Value.ToString();
                    }
                }
            }
            
            carr.Show();
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
            txtApellido.Enabled = true;
        }

        private void txtApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
            txtCedula.Enabled = true;
        }

        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 58 && e.KeyChar <= 127)
            {
                e.Handled = true;
                return;
            }
            txtDireccion.Enabled = true;
        }

        private void txtDireccion_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtCuenta.Enabled = true;
        }

        private void txtCuenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 58 && e.KeyChar <= 127)
            {
                e.Handled = true;
                return;
            }
            txtDireccion.Enabled = true;
        }
    }
}
