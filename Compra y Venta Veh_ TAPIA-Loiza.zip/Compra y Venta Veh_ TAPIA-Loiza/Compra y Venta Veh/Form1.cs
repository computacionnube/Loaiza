﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Compra_y_Venta_Veh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void iniciar()
        {
            pb1.Increment(1);
            if (pb1.Value == pb1.Maximum)
            {
                Reloj.Stop();
                this.Hide();
                Usuario usua = new Usuario();
                usua.Show();
            }
        }

        private void Reloj_Tick(object sender, EventArgs e)
        {
            this.iniciar();
        }
    }
}
